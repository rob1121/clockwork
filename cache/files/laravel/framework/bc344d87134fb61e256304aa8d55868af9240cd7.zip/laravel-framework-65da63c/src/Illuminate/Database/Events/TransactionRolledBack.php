<?php

namespace Illuminate\Database\Events;

class TransactionRolledBack extends ConnectionEvent
{
    //
}

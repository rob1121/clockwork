<?php
use PHPUnit\Framework\TestCase;

/**
 * @group bar
 */
class TwoTest extends TestCase
{
    public function testSomething()
    {
        $this->assertTrue(true);
    }
}

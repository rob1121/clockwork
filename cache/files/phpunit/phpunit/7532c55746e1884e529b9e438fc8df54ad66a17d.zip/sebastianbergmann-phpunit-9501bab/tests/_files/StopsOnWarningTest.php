<?php
use PHPUnit\Framework\TestCase;

class StopsOnWarningTest extends TestCase
{
    public function testOne()
    {
    }
}

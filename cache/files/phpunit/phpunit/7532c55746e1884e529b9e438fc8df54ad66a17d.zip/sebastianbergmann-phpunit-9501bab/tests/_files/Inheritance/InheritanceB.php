<?php

use PHPUnit\Framework\TestCase;

class InheritanceB extends TestCase
{
    public function testSomething()
    {
    }
}
